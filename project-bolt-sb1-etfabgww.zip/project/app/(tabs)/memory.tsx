import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAIStore } from '@/store/ai';

export default function MemoryScreen() {
  const { memories, personality } = useAIStore();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>AI Memory Bank</Text>
        <Text style={styles.subtitle}>
          Personality Trait: {personality.trait} (Level {personality.level})
        </Text>
      </View>

      <ScrollView style={styles.memoriesContainer}>
        {memories.map((memory) => (
          <View key={memory.id} style={styles.memoryCard}>
            <Text style={styles.memoryTitle}>{memory.topic}</Text>
            <Text style={styles.memoryText}>{memory.content}</Text>
            <Text style={styles.memoryDate}>
              {new Date(memory.timestamp).toLocaleDateString()}
            </Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#888',
  },
  memoriesContainer: {
    flex: 1,
    padding: 16,
  },
  memoryCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  memoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  memoryText: {
    fontSize: 16,
    color: '#ccc',
    marginBottom: 8,
  },
  memoryDate: {
    fontSize: 14,
    color: '#666',
  },
});