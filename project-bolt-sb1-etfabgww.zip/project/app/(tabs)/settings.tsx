import { View, Text, StyleSheet, Switch, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAIStore } from '@/store/ai';

export default function SettingsScreen() {
  const { settings, updateSettings, resetMemory } = useAIStore();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>AI Settings</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Behavior</Text>
        
        <View style={styles.setting}>
          <Text style={styles.settingLabel}>Learn from Conversations</Text>
          <Switch
            value={settings.learning}
            onValueChange={(value) => updateSettings({ learning: value })}
          />
        </View>

        <View style={styles.setting}>
          <Text style={styles.settingLabel}>Show Emotions</Text>
          <Switch
            value={settings.emotions}
            onValueChange={(value) => updateSettings({ emotions: value })}
          />
        </View>

        <View style={styles.setting}>
          <Text style={styles.settingLabel}>Adaptive Responses</Text>
          <Switch
            value={settings.adaptive}
            onValueChange={(value) => updateSettings({ adaptive: value })}
          />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Memory Management</Text>
        <Pressable 
          style={styles.dangerButton}
          onPress={resetMemory}>
          <Text style={styles.dangerButtonText}>Reset AI Memory</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  section: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 16,
  },
  setting: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  settingLabel: {
    fontSize: 16,
    color: '#fff',
  },
  dangerButton: {
    backgroundColor: '#ff3b30',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  dangerButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});