import { useCallback, useRef, useState } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, { 
  useAnimatedStyle, 
  withSpring,
  withSequence,
  withTiming,
  useSharedValue
} from 'react-native-reanimated';
import { useAIStore } from '@/store/ai';
import { AICharacter } from '@/components/AICharacter';
import { MessageBubble } from '@/components/MessageBubble';

export default function ChatScreen() {
  const [message, setMessage] = useState('');
  const scrollViewRef = useRef<ScrollView>(null);
  const { messages, personality, addMessage } = useAIStore();
  const bounceValue = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: bounceValue.value }],
    };
  });

  const handleSend = useCallback(() => {
    if (!message.trim()) return;

    // Animate the AI character
    bounceValue.value = withSequence(
      withSpring(1.1),
      withSpring(1)
    );

    // Add user message
    addMessage({
      id: Date.now().toString(),
      text: message,
      sender: 'user',
      timestamp: new Date(),
    });

    // Simulate AI response (replace with actual AI integration)
    setTimeout(() => {
      addMessage({
        id: (Date.now() + 1).toString(),
        text: `Based on my ${personality.trait} personality, I think that's interesting!`,
        sender: 'ai',
        timestamp: new Date(),
      });
    }, 1000);

    setMessage('');
  }, [message, addMessage, personality, bounceValue]);

  return (
    <SafeAreaView style={styles.container}>
      <Animated.View style={[styles.characterContainer, animatedStyle]}>
        <AICharacter />
      </Animated.View>

      <ScrollView
        ref={scrollViewRef}
        style={styles.messagesContainer}
        contentContainerStyle={styles.messagesContent}
        onContentSizeChange={() => scrollViewRef.current?.scrollToEnd()}>
        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
      </ScrollView>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={message}
          onChangeText={setMessage}
          placeholder="Type a message..."
          placeholderTextColor="#666"
          multiline
        />
        <Pressable style={styles.sendButton} onPress={handleSend}>
          <Text style={styles.sendButtonText}>Send</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  characterContainer: {
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#333',
    backgroundColor: '#1a1a1a',
  },
  input: {
    flex: 1,
    backgroundColor: '#333',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    color: '#fff',
    marginRight: 8,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: '#0066ff',
    borderRadius: 20,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  sendButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});