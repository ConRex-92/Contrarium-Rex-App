import { create } from 'zustand';
import type { Message, Memory, AIPersonality, AISettings } from '@/types';

interface AIState {
  messages: Message[];
  memories: Memory[];
  personality: AIPersonality;
  settings: AISettings;
  addMessage: (message: Message) => void;
  addMemory: (memory: Memory) => void;
  updatePersonality: (updates: Partial<AIPersonality>) => void;
  updateSettings: (updates: Partial<AISettings>) => void;
  resetMemory: () => void;
}

export const useAIStore = create<AIState>((set) => ({
  messages: [],
  memories: [
    {
      id: '1',
      topic: 'User Preferences',
      content: 'User enjoys discussing technology and AI development.',
      timestamp: new Date(),
      importance: 0.8,
    },
  ],
  personality: {
    trait: 'curious',
    level: 1,
    experience: 0,
  },
  settings: {
    learning: true,
    emotions: true,
    adaptive: true,
  },
  addMessage: (message) =>
    set((state) => ({
      messages: [...state.messages, message],
    })),
  addMemory: (memory) =>
    set((state) => ({
      memories: [...state.memories, memory],
    })),
  updatePersonality: (updates) =>
    set((state) => ({
      personality: { ...state.personality, ...updates },
    })),
  updateSettings: (updates) =>
    set((state) => ({
      settings: { ...state.settings, ...updates },
    })),
  resetMemory: () =>
    set((state) => ({
      memories: [],
      personality: {
        trait: 'curious',
        level: 1,
        experience: 0,
      },
    })),
}));