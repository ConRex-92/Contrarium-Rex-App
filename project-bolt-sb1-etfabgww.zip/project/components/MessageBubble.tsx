import { View, Text, StyleSheet } from 'react-native';
import type { Message } from '@/types';

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isAI = message.sender === 'ai';

  return (
    <View style={[
      styles.container,
      isAI ? styles.aiContainer : styles.userContainer,
    ]}>
      <Text style={styles.text}>{message.text}</Text>
      <Text style={styles.timestamp}>
        {new Date(message.timestamp).toLocaleTimeString()}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
    marginBottom: 8,
  },
  aiContainer: {
    backgroundColor: '#0066ff',
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 4,
  },
  userContainer: {
    backgroundColor: '#333',
    alignSelf: 'flex-end',
    borderBottomRightRadius: 4,
  },
  text: {
    color: '#fff',
    fontSize: 16,
  },
  timestamp: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 12,
    marginTop: 4,
    alignSelf: 'flex-end',
  },
});