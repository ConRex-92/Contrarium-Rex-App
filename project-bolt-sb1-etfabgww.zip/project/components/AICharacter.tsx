import { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  Easing,
  cancelAnimation,
} from 'react-native-reanimated';
import { useAIStore } from '@/store/ai';

export function AICharacter() {
  const { personality } = useAIStore();
  
  // Animation values
  const eyeBlinkValue = useSharedValue(1);
  const mouthValue = useSharedValue(0);
  const bodyValue = useSharedValue(1);

  // Animate body breathing
  useEffect(() => {
    bodyValue.value = withRepeat(
      withSequence(
        withTiming(1.05, { 
          duration: 2000, 
          easing: Easing.bezier(0.4, 0, 0.2, 1)
        }),
        withTiming(1, { 
          duration: 2000, 
          easing: Easing.bezier(0.4, 0, 0.2, 1)
        })
      ),
      -1,
      true
    );

    return () => {
      cancelAnimation(bodyValue);
    };
  }, []);

  // Blink animation
  useEffect(() => {
    let blinkTimeout: NodeJS.Timeout;

    const blink = () => {
      eyeBlinkValue.value = withSequence(
        withTiming(0.1, { 
          duration: 100,
          easing: Easing.bezier(0.4, 0, 0.2, 1)
        }),
        withTiming(1, { 
          duration: 100,
          easing: Easing.bezier(0.4, 0, 0.2, 1)
        })
      );
      
      // Random interval for next blink
      const nextBlink = 2000 + Math.random() * 3000;
      blinkTimeout = setTimeout(blink, nextBlink);
    };

    blink();

    return () => {
      if (blinkTimeout) {
        clearTimeout(blinkTimeout);
      }
      cancelAnimation(eyeBlinkValue);
    };
  }, []);

  const bodyStyle = useAnimatedStyle(() => ({
    transform: [{ scale: bodyValue.value }],
  }));

  const eyeStyle = useAnimatedStyle(() => ({
    transform: [{ scaleY: eyeBlinkValue.value }],
  }));

  const mouthStyle = useAnimatedStyle(() => ({
    transform: [{ scaleY: mouthValue.value + 1 }],
  }));

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.body, bodyStyle]}>
        <View style={styles.face}>
          <View style={styles.eyesContainer}>
            <Animated.View style={[styles.eye, eyeStyle]} />
            <Animated.View style={[styles.eye, eyeStyle]} />
          </View>
          <Animated.View style={[styles.mouth, mouthStyle]} />
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: '#0066ff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  face: {
    alignItems: 'center',
  },
  eyesContainer: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  eye: {
    width: 8,
    height: 20,
    borderRadius: 4,
    backgroundColor: '#fff',
    marginHorizontal: 15,
  },
  mouth: {
    width: 30,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
});