export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export interface Memory {
  id: string;
  topic: string;
  content: string;
  timestamp: Date;
  importance: number;
}

export interface AIPersonality {
  trait: string;
  level: number;
  experience: number;
}

export interface AISettings {
  learning: boolean;
  emotions: boolean;
  adaptive: boolean;
}